rm(list = ls())

###################################################################################
# 1.1 Plot model performance on training data                                     #
###################################################################################
setwd("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out")
library(tidyverse)
library(ggpubr)
library(ggplot2)
library(ggsci)
library(scales)
#mypal = pal_npg("nrc")(9)
#show_col(mypal)
#mypal2 = pal_jco()(9)
#show_col(mypal2)
#load("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_models_compare_230328.Rdata")
load("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_models_compare_multinom_230328.Rdata")
#RF
rf_value <- models_compare$values[,c(1,2,3,4,8,11,12,13,14)]
rf_value$model = rep("RF",5)
rf_value
names(rf_value)[2:9] = c("Accuracy","AUC","Kappa","Mean_F1","Mean_Precision","Mean_Recall",
                         "Mean_Sensitivity","Mean_Specificity")
## SVM
svm_value <- models_compare$values[,c(1,16,17,18,22,25,26,27,28)]
svm_value
svm_value$model = rep("SVM",5)
names(svm_value)[2:9] = c("Accuracy","AUC","Kappa","Mean_F1","Mean_Precision","Mean_Recall",
                          "Mean_Sensitivity","Mean_Specificity")
## LR
lr_value <- models_compare$values[,c(1,30,31,32,36,39,40,41,42)]
lr_value
lr_value$model = rep("LR",5)
names(lr_value)[2:9] = c("Accuracy","AUC","Kappa","Mean_F1","Mean_Precision","Mean_Recall",
                         "Mean_Sensitivity","Mean_Specificity")

rbind(rf_value,svm_value,lr_value) %>%
   gather(metrics,values,-c(1,10)) -> models_compare_long

compare_means(values ~ model, models_compare_long, method = "t.test", group.by = "metrics")

ggbarplot(models_compare_long,x="metrics",y="values",fill = "model",
          palette = c("#3C5488FF","#EFC000FF","#868686FF"), 
          #palette = "jco", 
          add = "mean_se",
          position = position_dodge(0.8),alpha = 0.7)+
          labs(x = "",y="Model Performace")+
          scale_y_continuous(expand=c(0.02,0),limits=c(0, 1),breaks=seq(0,1,0.1))+
          theme(legend.position = 'right',
               legend.text = element_text(color="black",size = 15),
               legend.title = element_text(color="black",size = 15),
               axis.text = element_text(color="black", size=15),
               axis.title.y = element_text(color="black", size=15),
               #axis.line = element_line(colour = "black",size = 0.1)
              )

ggsave("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_train_models_compare_barplot_multinom_230328.pdf",width = 16,height =5,dpi = 300)

my_comparisons = list( c("RF", "LR"), c("RF", "SVM"), c("SVM", "LR") )

p0<- ggbarplot(models_compare_long,x="model",y="values",fill = "model",
          palette = c("#3C5488FF","#EFC000FF","#868686FF"), 
          #palette = "jco", 
          facet.by = "metrics",
          nrow=2,
          add = "mean_se",
          position = position_dodge(0.8),alpha = 0.7) +
          stat_compare_means(comparisons = my_comparisons,method = "t.test",label = "p.signif") + # Add pairwise comparisons p-value
          #stat_compare_means(label.y = 1.10) +
          labs(x = "",y="Model Performace")+
          scale_y_continuous(expand=c(0.02,0),limits=c(0, 1.27),breaks=seq(0,1.27,0.2))+
          theme(legend.position = 'none')
p0
ggsave("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_train_models_compare_barplot_pavlue_multinom_230328.pdf",width = 8,height =6,dpi = 300)

###################################################################################
# 1.2 Plot model performance on test data                                         #
###################################################################################
# Ref:https://www.jianshu.com/p/3a90706382da
#install.packages("fmsb")
#library(fmsb)
#install.packages("devtools")
#devtools::install_github("ricardo-bion/ggradar", dependencies=TRUE)
#install.packages("remotes")
#remotes::install_github("dami82/ggradarSIZE")
library(ggradar)
#library(ggradarSIZE)
## load data
load("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_rf_conMatrix_230328.Rdata")
#load("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_lr_conMatrix_230328.Rdata")
load("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_lr_conMatrix_multinom_230328.Rdata")
load("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_svm_conMatrix_230328.Rdata")

rf_conMatrix_d <- as.data.frame(rf_conMatrix$byClass)
row.names(rf_conMatrix_d) =c("Bovine","Fish","Human","Pig")
names(rf_conMatrix_d)[c(3:4,9:11)]=c("Pos_Pred_Value","Neg_Pred_Value","Detection_Rate",
                                     "Detection_Prevalence","Balanced_Accuracy")
rf_conMatrix_d$Class = row.names(rf_conMatrix_d)
rf_conMatrix_d2 <- rf_conMatrix_d[,c(12,1:11)]
rf_conMatrix_d2


lr_conMatrix_d <- as.data.frame(lr_conMatrix$byClass)
row.names(lr_conMatrix_d) =c("Bovine","Fish","Human","Pig")
names(lr_conMatrix_d)[c(3:4,9:11)]=c("Pos_Pred_Value","Neg_Pred_Value","Detection_Rate",
                                     "Detection_Prevalence","Balanced_Accuracy")
lr_conMatrix_d
lr_conMatrix_d$Class = row.names(lr_conMatrix_d)
lr_conMatrix_d2 <- lr_conMatrix_d[,c(12,1:11)]
lr_conMatrix_d2

svm_conMatrix_d <- as.data.frame(svm_conMatrix$byClass)
row.names(svm_conMatrix_d) =c("Bovine","Fish","Human","Pig")
names(svm_conMatrix_d)[c(3:4,9:11)]=c("Pos_Pred_Value","Neg_Pred_Value","Detection_Rate",
                                     "Detection_Prevalence","Balanced_Accuracy")
svm_conMatrix_d
svm_conMatrix_d$Class = row.names(svm_conMatrix_d)
svm_conMatrix_d2 <- svm_conMatrix_d[,c(12,1:11)]
svm_conMatrix_d2

lcols <- c("#0073C2FF","#EFC000FF","#868686FF","#CD534CFF")
p1 <- ggradar(rf_conMatrix_d2[,c(1:3,6:8)],base.size = 12,
        legend.text.size = 12,
        legend.position = "right",
        group.line.width = 1,
        group.point.size = 4,
        group.colours = lcols)

p2 <- ggradar(lr_conMatrix_d2[,c(1:3,6:8)],base.size = 12,
              legend.text.size = 12,
              legend.position = "right",
              group.line.width = 1,
              group.point.size = 4,
              group.colours = lcols)

p3 <- ggradar(svm_conMatrix_d2[,c(1:3,6:8)],base.size = 12,
              legend.text.size = 12,
              legend.position = "right",
              group.line.width = 1,
              group.point.size = 4,
              group.colours = lcols)

###################################################################################
# 1.3 Output plot.                                                                #
###################################################################################
library(patchwork)

p4 <- p1 + p2 + p3 + plot_layout(guides = 'collect',nrow = 3)
p4
ggsave("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_test_radarplot_multinom_230328.pdf",width = 6,height = 10,dpi = 300)

p0 + p4 + plot_layout(widths = c(3, 1),nrow = 1)

ggsave("D:/01-project/HK/02-GBS_Carmen/220126_set12_out/01caret_ML_out/host_performance_all_plot_multinom_230328.pdf",width = 12,height = 6,dpi = 300)


