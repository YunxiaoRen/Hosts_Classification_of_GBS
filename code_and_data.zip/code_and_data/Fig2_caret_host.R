################################################################################### 
#                           1. Load the caret package                             #
###################################################################################
library(caret)
library(randomForest)
library(kernlab)
library(caTools)
#library(xgboost)
#library(adabag)
#library(caretEnsemble)
library(MLmetrics)

################################################################################### 
#                           2. Data Processing                                    #
# split train and test data; define the training control                          #
###################################################################################
rm(list=ls())
setwd("./inputdata")
data <- read.csv("host_final_filter_data.csv")
dim(data)
#[1] 1241 3895
data[1:5,1:5]
names(data)[1]="sample_name"

pheno <- read.csv("host_final_pheno.csv")
head(pheno)
pheno$label[pheno$label==0]="Bovine"
pheno$label[pheno$label==1]="Fish"
pheno$label[pheno$label==2]="Human"
pheno$label[pheno$label==3]="Pig"

rawdata <- merge(pheno,data,by="sample_name")
dim(rawdata)
rawdata[1:5,1:5]
rownames(rawdata) = rawdata$sample_name
rawdata = rawdata[,-1]
# Create the training and test datasets
set.seed(100)

rawdata$label=as.factor(rawdata$label) # important for svm/lr model
# Step 1: Get row numbers for the training data
trainRowNumbers <- createDataPartition(rawdata$label, p=0.8, list=FALSE)
# Step 2: Create the training  dataset
trainData <- rawdata[trainRowNumbers,]
save(trainData, file="host_model_trainData.Rdata")
write.csv(trainData,file="host_model_trainData.csv",quote = F)
#load("host_model_trainData_230328.Rdata")
dim(trainData)
# Step 3: Create the test dataset
testData <- rawdata[-trainRowNumbers,]
dim(testData)
save(testData, file="host_model_testData_.Rdata")
write.csv(testData,file="host_model_testData.csv",quote = F)
#load("host_model_testData_230328.Rdata")
# Define the training control
fitControl <- trainControl(
  method = 'cv',                   # k-fold cross validation
  number = 5,                      # number of folds
  savePredictions = 'final',       # saves predictions for optimal tuning parameter
  classProbs = T,                  # should class probabilities be returned
  summaryFunction=multiClassSummary  # results summary function. twoClassSummary or multiClassSummary
)

################################################################################### 
#             3. Model Training  and Prediction                                   #
###################################################################################
## 3.1 Train the model using RF, SVM(linear), LR                                  #
###################################################################################
set.seed(100)
model_rf = train(label ~ ., data=trainData, method='rf',tuneLength=5, trControl = fitControl)
model_rf
save(model_rf, file="host_model_rf.Rdata")

model_svm =  train(label ~ ., data=trainData, method='svmLinear',tuneLength=5, trControl = fitControl)
model_svm
save(model_svm, file="host_model_svm.Rdata")

#model_lr =  train(label ~ ., data=trainData, method='LogitBoost',tuneLength=5, trControl = fitControl)
model_lr =  train(label ~ ., data=trainData, method='multinom',tuneLength=5,trControl = fitControl,trace = FALSE,MaxNWts=100000)
model_lr
save(model_lr, file="host_model_lr_multinom.Rdata")

###################################################################################
## 3.2 Compare models' performances                                               #
###################################################################################

# Compare model performances using resample()
models_compare <- resamples(list(RF=model_rf, SVM=model_svm, LR=model_lr))
# Summary of the models performances
summary(models_compare)

summary_out = summary(models_compare)
## LR=method='LogitBoost'
#save(models_compare, file="host_models_compare.Rdata")
#write.csv(models_compare$values,file="host_models_compare_out.csv",quote = F,row.names = F)

## LR=method='multinom'
save(models_compare, file="host_models_compare_multinom.Rdata")
write.csv(models_compare$values,file="host_models_compare_out_multinom.csv",quote = F,row.names = F)

###################################################################################
## 3.3 Prediction of models                                                       #
###################################################################################
## prediction
rf_predicteds <- predict(model_rf, newdata=testData)
head(rf_predicteds)
rf_predicteds_probs <- predict(model_rf, newdata=testData,'prob')
rf_conMatrix = confusionMatrix(reference = as.factor(testData$label), data = rf_predicteds, mode='everything')
save(rf_conMatrix, file="host_rf_conMatrix.Rdata")

lr_predicteds <- predict(model_lr, newdata=testData)
head(lr_predicteds)
lr_predicteds_probs <- predict(model_lr, newdata=testData,'prob')
lr_conMatrix = confusionMatrix(reference = as.factor(testData$label), data =lr_predicteds, mode='everything')
#save(lr_conMatrix, file="host_lr_conMatrix.Rdata")
save(lr_conMatrix, file="host_lr_conMatrix_multinom.Rdata")

svm_predicteds <- predict(model_svm, newdata=testData)
head(svm_predicteds)
svm_predicteds_probs <- predict(model_svm, newdata=testData,'prob')
svm_conMatrix = confusionMatrix(reference = as.factor(testData$label), data = svm_predicteds, mode='everything')
save(svm_conMatrix, file="host_svm_conMatrix.Rdata")



################################################################################### 
#                        6. Correlation                                           #
###################################################################################

# ### false predictions
ref = as.factor(testData$label)

# #### false prediction by shap on RF and LR
false_pre_dat<- testData[c(22,87, 92,136,162,198),]
true_name = false_pre_dat$label
true_name
# [1] Fish   Human  Pig    Bovine Bovine Fish 
# y_pred[[21,86, 91,135,161,197]]
# #array(['Human', 'Pig', Human', 'Human', 'Human', 'Human'], dtype=object)
# #Y_test[[21,91,135,161,197]]
# #CUHK_fGBS802A_18      Fish
# #CUHK_pGBS19A_18        Pig
# #GCA_000323085.1     Bovine
# #GCA_001017935.1     Bovine
# #GCA_001592635.1       Fish
# 
library(corrplot)
t2 = as.data.frame(t(false_pre_dat))
names(t2)=c("Fish1","Human","Pig","Bovine1","Bovine2","Fish2")
t3= as.data.frame(sapply(t2[2:3895,1:6], as.numeric))
env.cor <- round(cor(t3, method = 'pearson'),3)
col2 <- colorRampPalette(c("#053061","#2166AC","#4393C3","#92C5DE","#D1E5F0",
                           "#FFFFFF","#FDDBC7","#F4A582","#D6604D","#B2182B", "#67001F"))

pdf(file="host_false_pre_cor_shap_RF_LR.pdf")
corrplot.mixed(env.cor,order = 'AOE',tl.col = "black",upper.col = col2(200))
dev.off()